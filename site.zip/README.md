# Portfolio Site (Next.js + Tailwind)

English content based on your resume. Monochrome theme (black/white), yellow links, Inter as main font, monospace as secondary, Lucide icons.

## Quick start

1) Install dependencies
```bash
npm install
```

2) Run dev server
```bash
npm run dev
```

Then open http://localhost:3000

## Assets
- Place your portrait at `public/portrait.png`.
- Put your resume PDF at `public/resume.pdf`.

## Notes
- Hero includes WhatsApp (Hire Me), Email, and Download CV.
- Stats reflect achievements from the resume.
