Components will be placed here as the project grows (Header, Footer, etc.). For MVP we used inline components in app/page.tsx to keep things simple.
